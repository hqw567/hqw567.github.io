import{d as i}from"../chunk-YZ7E3ATC.js";import"../chunk-TTX6TVTO.js";i(window.CONFIG.waline.cdn,()=>{new window.Waline(window.CONFIG.waline.config)},window.Waline);
